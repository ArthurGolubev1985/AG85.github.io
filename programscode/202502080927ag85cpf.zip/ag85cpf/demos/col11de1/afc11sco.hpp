
#pragma once
#ifndef AFC11SCO_1_HPP //AG19850316CppframebraryPartCoreLibraryCpp2011Demo1ProgramStaticconfiguration
#define AFC11SCO_1_HPP //AG19850316CppframebraryPartCoreLibraryCpp2011Demo1ProgramStaticconfiguration

#include <string>

namespace AG85{

	namespace Cppframebrary{

		namespace CoreLibraryCpp2011Demo1{

			namespace StaticConfiguration{

				static const char APPLICATION_NAME[] = "AG85Cpp2011framebraryCoreLibraryCpp2011Demo1";
				enum { APPLICATION_VERSION_NUMBER = 1 };

			}; //class StaticConfiguration

		} //namespace CoreLibraryCpp2011Demo1

	} //namespace Cppframebrary

} //namespace AG19850316

#endif //AFC11SCO_1_HPP - AG19850316CppframebraryPartCoreLibraryCpp2011Demo1ProgramStaticconfiguration

// Author: Arthur Golubev 1985 (ArthurGolubev1985)
// This file is a part of AG19850316 C++ Framebrary (ag85cppframebrary)
