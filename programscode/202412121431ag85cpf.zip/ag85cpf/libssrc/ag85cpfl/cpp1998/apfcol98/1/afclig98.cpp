
#include "afclig98.hpp" //AG19850316CppframebraryPartCorelibraryGlobalIncrementingintegeridentificatorsgeneratorCpp1998

namespace AG85{

	namespace Cppframebrary{

        namespace Corelibrary1{

            namespace CppVersion1998{

                unsigned int GlobalIncrementalunsignedintegeridentificatorsgenerator::incrementingintegeridsgenerator = 0;

            } //namespace Corelibrary1

        } //namespace CppVersion1998

	} //namespace Cppframebrary

} //namespace AG19850316

// Author: Arthur Golubev 1985 (ArthurGolubev1985)
// This file is a part of AG19850316 C++ Framebrary (ag85cppframebrary)
