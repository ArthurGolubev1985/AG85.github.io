
#pragma once
#ifndef A85FCSC_HPP //AG19850316Cppframebrary1PartCore1Applicationblank1Applicationstaticconfiguration
#define A85FCSC_HPP //AG19850316Cppframebrary1PartCore1Applicationblank1Applicationstaticconfiguration

#include <string>

namespace AG85{

	namespace Cppframebrary1{
	
		namespace CppVersion1998{

			namespace Application{

				namespace StaticConfiguration{

					static const char APPLICATION_NAME[] = "AG85Cpp1998framebrary1Core1Apllicationblank";
					enum { APPLICATION_VERSION = 1 };
					
				}; //class StaticConfiguration

			} //namespace Application

		} //namespace CppVersion1998

	} //namespace Cppframebrary1

} //namespace AG19850316

#endif //A85FCSC_HPP - AG19850316Cppframebrary1PartCore1Applicationblank1Applicationstaticconfiguration

// Author: Arthur Golubev 1985 (ArthurGolubev1985)
