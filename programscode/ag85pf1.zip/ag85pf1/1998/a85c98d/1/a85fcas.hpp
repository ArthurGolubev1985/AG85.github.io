
#pragma once
#ifndef A85FCAS_HPP //AG19850316Cppframebrary1PartCore1Applicationblank1Applicationstaticconfiuration
#define A85FCAS_HPP //AG19850316Cppframebrary1PartCore1Applicationblank1Applicationstaticconfiuration

namespace AG85{

	namespace Cppframebrary1{
	
		namespace Application{

			namespace StaticConfiguration{

				static const char APPLICATION_NAME[] = "AG85Cpp1998framebrary1Core1Apllicationblank";
				enum { APPLICATION_VERSION_NUMBER = 1 };
				
			}; //class StaticConfiguration

		} //namespace Application

	} //namespace Cppframebrary1

} //namespace AG19850316

#endif //A85FCAS_HPP - AG19850316Cppframebrary1PartCore1Applicationblank1Applicationstaticconfiuration

// Author: Arthur Golubev 1985 (ArthurGolubev1985)
// The file is a part of AG19850316 C++ Framebrary 1 (ag85cppframebrary1)
