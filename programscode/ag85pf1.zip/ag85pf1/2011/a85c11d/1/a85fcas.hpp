
#pragma once
#ifndef A85FCAS_HPP //AG19850316Cppframebrary1Part2011Core1Applicationblank1Applicationstaticconfiguration
#define A85FCAS_HPP //AG19850316Cppframebrary1Part2011Core1Applicationblank1Applicationstaticconfiguration

#include <string>

namespace AG85{

	namespace Cppframebrary1{

		namespace Application{

			namespace StaticConfiguration{

				static const char APPLICATION_NAME[] = "AG85Cpp2011framebrary1Core1Apllicationblank";
				enum { APPLICATION_VERSION_NUMBER = 1 };

			}; //class StaticConfiguration

		} //namespace Application

	} //namespace Cppframebrary1

} //namespace AG19850316

#endif //A85FCAS_HPP - AG19850316Cppframebrary1Part2011Core1Applicationblank1Applicationstaticconfiguration

// Author: Arthur Golubev 1985 (ArthurGolubev1985)
// The file is a part of AG19850316 C++ Framebrary 1 (ag85cppframebrary1)
