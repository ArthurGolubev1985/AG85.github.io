
#pragma once
#ifndef A85FCBC_HPP //AG19850316Cppframebrary1PartCore1Applicationblank1Buildconfiguration
#define A85FCBC_HPP //AG19850316Cppframebrary1PartCore1Applicationblank1Buildconfiguration

//#define AG19850316_1CPPGENERALLIBRARY_TIMER_DISABLED

#endif //A85FCBC_HPP - AG19850316Cppframebrary1PartCore1Applicationblank1Buildconfiguration

// Author: Arthur Golubev 1985 (ArthurGolubev1985)
