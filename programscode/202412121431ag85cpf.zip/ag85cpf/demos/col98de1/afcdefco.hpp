
#pragma once
#ifndef AFCDEFCO_1_HPP //AG19850316CppframebraryCorelibraryCpp1998Demo1ProgramCppdefinesconfiguration
#define AFCDEFCO_1_HPP //AG19850316CppframebraryCorelibraryCpp1998Demo1ProgramCppdefinesconfiguration

#//define AG19850316_AFCLST98_1_TIMER_DISABLED

#endif //AFCDEFCO_1_HPP - AG19850316CppframebraryCorelibraryCpp1998Demo1ProgramCppdefinesconfiguration

// Author: Arthur Golubev 1985 (ArthurGolubev1985)
// This file is a part of AG19850316 C++ Framebrary (ag85cppframebrary)
