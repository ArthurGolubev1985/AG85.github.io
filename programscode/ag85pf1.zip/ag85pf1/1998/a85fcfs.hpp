
#pragma once
#ifndef A85FCFS_HPP //AG19850316Cppframebrary1PartCore1Framebrarystaticconfiuration
#define A85FCFS_HPP //AG19850316Cppframebrary1PartCore1Framebrarystaticconfiuration

namespace AG85{

	namespace Cppframebrary1{
	
		namespace StaticConfiguration{

			enum { FRAMEBRARY_VERSION_NUMBER = 1 };
			
		}; //class StaticConfiguration

	} //namespace Cppframebrary1

} //namespace AG19850316

#endif //A85FCFS_HPP - AG19850316Cppframebrary1PartCore1Applicationblank1Applicationstaticconfiguration

// Author: Arthur Golubev 1985 (ArthurGolubev1985)
// The file is a part of AG19850316 C++ Framebrary 1 (ag85cppframebrary1)
