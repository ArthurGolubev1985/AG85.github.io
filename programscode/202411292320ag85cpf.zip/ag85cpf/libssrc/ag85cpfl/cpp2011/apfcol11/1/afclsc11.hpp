
#pragma once
#ifndef AFCLSC11_1_HPP //AG19850316CppframebraryPartCorelibrary1FramebraryStaticconfigurationCpp2011
#define AFCLSC11_1_HPP //AG19850316CppframebraryPartCorelibrary1FramebraryStaticconfigurationCpp2011

namespace AG85{

	namespace Cppframebrary{
	
		namespace CoreLibrary1{

			namespace StaticConfiguration{

		        namespace CppVersion2011{

					enum { LIBRARY_PART_NUMBER = 1 };
					
				} //namespace CppVersion1998

			} //namespace StaticConfiguration

		} //namespace CoreLibrary1

	} //namespace Cppframebrary

} //namespace AG19850316

#endif //AFCLSC11_1_HPP - AG19850316CppframebraryPartCorelibrary1FramebraryStaticconfigurationCpp2011

// Author: Arthur Golubev 1985 (ArthurGolubev1985)
// This file is a part of AG19850316 C++ Framebrary (ag85cppframebrary)
