
#pragma once
#ifndef AFC98SCO_1_HPP //AG19850316CppframebraryPartCoreLibraryCpp1998Demo1ProgramStaticconfiguration
#define AFC98SCO_1_HPP //AG19850316CppframebraryPartCoreLibraryCpp1998Demo1ProgramStaticconfiguration

namespace AG85{

	namespace Cppframebrary{
	
		namespace CoreLibraryCpp1998Demo1{

			namespace StaticConfiguration{

				static const char APPLICATION_NAME[] = "AG85Cpp1998framebraryCoreLibraryCpp1998Demo1";
				enum { APPLICATION_VERSION_NUMBER = 1 };
				
			} //namespace StaticConfiguration

		} //namespace Application

	} //namespace Cppframebrary

} //namespace AG19850316

#endif //AFC98SCO_1_HPP - AG19850316CppframebraryPartCoreLibraryCpp1998Demo1ProgramStaticconfiguration

// Author: Arthur Golubev 1985 (ArthurGolubev1985)
// This file is a part of AG19850316 C++ Framebrary (ag85cppframebrary)
