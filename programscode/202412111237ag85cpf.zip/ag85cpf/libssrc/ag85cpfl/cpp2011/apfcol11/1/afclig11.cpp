
#include <atomic>

#include "afclig11.hpp" //AG19850316CppframebraryPartCorelibrary1GlobalAtomicIncrementingintegeridentificatorsgeneratorCpp2011

namespace AG85{

	namespace Cppframebrary{

        namespace Corelibrary1{

            namespace CppVersion2011{

                std::atomic<unsigned int> GlobalAtomicIncrementalunsignedintegeridentificatorsgenerator::incrementingatomicintegeridsgenerator(0);

            } //namespace CppVersion2011

        } //namespace Corelibrary1

	} //namespace Cppframebrary

} //namespace AG19850316

// Author: Arthur Golubev 1985 (ArthurGolubev1985)
// This file is a part of AG19850316 C++ Framebrary (ag85cppframebrary)
